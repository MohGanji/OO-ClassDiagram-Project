import Person from './person';

export default class Professor {
  constructor(private person: Person, private pid: string) {}
}
