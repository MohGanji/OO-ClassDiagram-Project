export enum DayOfWeek {
  Sat,
  Sun,
  Mon,
  Tue,
  Wed,
  Thu,
  Fri
}
