export enum College {
  ece,
  centeralCollegeOfEngineering
}
