class MojavezHandlerSingleton {
  constructor() {}
}

const MojavezHandler = new MojavezHandlerSingleton();
export default MojavezHandler;
