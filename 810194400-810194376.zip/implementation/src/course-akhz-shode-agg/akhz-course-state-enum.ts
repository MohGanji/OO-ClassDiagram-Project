export enum AkhzCourseState {
  Registered,
  Pending,
  HazfEzterari,
  HazfPezeshki,
  Registered_in_HazfEzterari,
  Pending_in_HazfEzafe,
  Passed,
  Failed
}
