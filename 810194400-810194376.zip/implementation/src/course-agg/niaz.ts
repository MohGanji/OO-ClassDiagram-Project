export default abstract class Niaz {
  constructor() {}
}
