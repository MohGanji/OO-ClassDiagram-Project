export enum CourseTypeEnum {
  Theory,
  Practical
}
