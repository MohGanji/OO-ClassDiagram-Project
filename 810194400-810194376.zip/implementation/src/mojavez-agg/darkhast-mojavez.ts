export default class DarkhastMojavez {
  constructor(private description: string) {}
}
