export enum EducationalSeason {
  Fall,
  Spring
}
